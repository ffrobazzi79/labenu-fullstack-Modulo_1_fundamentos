# Funções de Array - Template de Prática
**Vamos utilizar esse repositório para as práticas da aula!**

## Instruções para baixar

1. Faça o fork desse repositório.
2. No repositório com seu nome de usuário, copie a url.
3. Abra a pasta onde você guarda os materiais do curso pelo terminal.
4. Baixe o repositório usando: git clone url-copiada.
5. Abra a pasta no vscode. Vamos codar!
