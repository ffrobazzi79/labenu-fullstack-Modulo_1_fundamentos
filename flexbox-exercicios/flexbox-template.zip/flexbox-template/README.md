# Flexbox - Template na Prática

Utilize os arquivos deste repo para facilitar o desenvolvimento da prática
