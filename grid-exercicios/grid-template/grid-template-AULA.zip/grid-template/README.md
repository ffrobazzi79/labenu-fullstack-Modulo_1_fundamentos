# Grid - Template da Prática

Utilize este template para executar as tarefas de aula!
