/*
Crie uma função
que receba por parâmetro um nome
e imprima no console a mensagem: 
`Olá ${nome}`

Invoque esta função 3 vezes, passando 3 argumentos (nomes) diferentes
*/

// Dentro de ${} entre crases, só podemos colocar expressões
// Expressão é qualquer coisa que gera um valor final
// Uma dica: é expressão se entra dentro de um console.log()

function pratica1Normal(nome) {
    console.log(`Olá ${nome}`)
    console.log("Olá", nome)
}

const pratica1Arrow = (nome) => {
    console.log(`Olá ${nome}`)
}

const pratica1ArrowAbreviada = (nome) => console.log(`Olá ${nome}`)

const pratica1ComReturn = (nome) => {
    return `Olá ${nome}`
}

pratica1Normal("João")
pratica1Arrow("bananinha")

pratica1Normal("Fulana")
pratica1Arrow("Ciclano")

console.log(pratica1ComReturn("Teste"))
