/*
Crie uma função que receba um número como parâmetro e:
verifique se ele é par
Some com o número 10
multiplique por ele mesmo
Retorne `o número ${numero} é par? ${verifica}. Somado com 1O o resultado é ${soma} e multiplicado por ele mesmo é  ${multiplica}`
Extra: Refaça o exercício com a sintaxe de expressão de função
*/

// algoritmo
// 1) dividir por 2 e pegar o resto
// 2) se o resto for 0 é par, senão é ímpar

function pratica2(num) {
    const verifica = num % 2 === 0
    const soma = num + 10
    const multiplica = num * num

    return `o número ${num} é par? ${verifica}.
Somado com 1O o resultado é ${soma} e multiplicado por ele mesmo é  ${multiplica}`
}

const numInformado = Number(prompt("Informe um número"))
console.log(pratica2(numInformado))